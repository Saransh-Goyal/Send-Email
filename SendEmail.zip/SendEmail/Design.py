from tkinter import *
from tkinter import filedialog
import docx
import xlrd
from docx.enum.text import WD_LINE_SPACING

class AppDesign:
    txt_var = ""
    word_var = ""
    def __init__(self, master):
        global txt_var, word_var
        self.master = master

        self.excelUpload = Button(master, bg='#32d943',width=10, font='verdana 10', text='Select Excel', fg='Black',
                                command=self.excelfile, bd=2)
        self.excelUpload.place(x=270, y=80)

        txt_var = StringVar(master, 'Enter keyword here...')
        self.text = Entry(master, width=40, state='readonly', textvariable=txt_var, bg='Light Grey', fg='Black', border=2)
        self.text.place(x=20, y=80)

        self.wordUpload = Button(master, bg='#32d943', width=10, font='verdana 10', text='Select Word', fg='Black',
                                  command=self.wordfile, bd=2)
        self.wordUpload.place(x=270, y=120)

        word_var = StringVar(master, 'Enter keyword here...')
        self.text = Entry(master, width=40, state='readonly', textvariable=word_var, bg='Light Grey', fg='Black',
                          border=2)
        self.text.place(x=20, y=120)

        self.edit = Button(master, bg='#32d943',width=10, font='verdana 10', text='Edit Word', fg='Black',
                                command=self.savefile, bd=2)
        self.edit.place(x=120, y=170)

    def excelfile(self):
        global txt_var
        selected_files = filedialog.askopenfiles(initialdir='"C://Users//Saransh Goyal//Desktop"',
                                                 title='Select the Excel File', filetypes=(('Excel Files', '*.xlsx'),
                                                                                            ('All Types', '*.*')))
        txt_var.set(selected_files[0].name)


    def wordfile(self):
        global word_var
        selected_files = filedialog.askopenfiles(initialdir='"C://Users//Saransh Goyal//Desktop"',
                                                 title='Select the Word File', filetypes=(('Word Files', '*.docx'),
                                                                                            ('All Types', '*.*')))
        word_var.set(selected_files[0].name)
        name = word_var.get()


    def savefile(self):
        global word_var, txt_var
        whole_text = ""
        wb = xlrd.open_workbook(txt_var.get())
        sheet = wb.sheet_by_index(0)
        word_doc = docx.Document(word_var.get())
        para = word_doc.paragraphs
        replaced_name = ""
        replaced_text = ""
        for x in para:
            whole_text = whole_text + x.text + '\n\n'
        print(whole_text.strip())
        for x in range(sheet.nrows):
            if x is not 0:
                replaced_text = whole_text.replace("<<name>>", sheet.row_values(x)[0])
                replaced_text = replaced_text.replace("<<phone>>", str(int((sheet.row_values(x)[1]))))
                replaced_text = replaced_text.replace("<<address>>", sheet.row_values(x)[2])
                print(replaced_text)
                new_doc = docx.Document()
                new_doc.add_paragraph(replaced_text.strip())
                #new_doc.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
                new_doc.save(f"C://Users//Saransh Goyal//Desktop//Template//{sheet.row_values(x)[0]}.docx")
"""
                if "<<name>>" in x.text:
                    
                    self.replaced_name = x.text.replace("<<name>>", sheet.row_values(xl))
                elif "<<phone>>" in x.text or "<<address>>" in x.text:
                    self.replaced_text = x.text.replace("<<phone>>", '1234567')
                    self.replaced_text = self.replaced_text.replace("<<address>>", 'abc')
            print(self.replaced_name)
            print(self.replaced_text)

            
"""