from tkinter import *
from Design import *


def mainwindow(win):
    root=win
    print(win)



def mainpage():
    root = Tk()
    AppDesign(root)
    #root.iconbitmap('Images/Logo.ico')
    root.title('Music Player')
    root.geometry('400x400')
    root.configure(bg='#34cfeb')
    root.resizable(False, False)
    root.mainloop()


if __name__ == "__main__":
    mainpage()
